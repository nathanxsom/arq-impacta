package pontos.interfaces;

import java.util.Map;


public class Mapeamento {
	public Mapeamento(Map<Character, Integer[]> mapa) {
		super();
		this.mapa = mapa;
	}

	private Map<Character, Integer[]> mapa;

	public Map<Character, Integer[]> getMapa() {
		return mapa;
	}
	
}
